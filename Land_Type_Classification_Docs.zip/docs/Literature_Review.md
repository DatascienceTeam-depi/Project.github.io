# Literature Review

## Related Work
Summarizing previous research on land classification using satellite images.

## Feedback & Improvements
Lecturer's evaluation and suggested enhancements.

## Final Grading Criteria
Breakdown of assessment categories.
