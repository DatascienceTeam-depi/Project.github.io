# Land Type Classification using Sentinel-2 Satellite Images

## Project Overview
This project leverages Deep Neural Networks (DNNs) to classify different land types (such as agriculture, water, urban areas, desert, roads, and trees) using Sentinel-2 satellite imagery. The objective is to create an accurate model that aids in urban planning, environmental monitoring, and resource management.

## Project Structure
- `docs/` - Contains all documentation related to the project.
- `data/` - Contains datasets (if applicable).
- `src/` - Code implementation of the project.
- `notebooks/` - Jupyter notebooks for data exploration and model training.
- `models/` - Saved models and evaluation results.

## Team Members
This project is developed by a team of three members, with tasks distributed fairly among them.

## Setup
1. Clone this repository.
2. Install dependencies using `pip install -r requirements.txt`.
3. Run the preprocessing scripts before training the model.

## Contributions
Each team member will contribute to data preprocessing, model development, and documentation.

## License
This project is open-source and available under the MIT License.
