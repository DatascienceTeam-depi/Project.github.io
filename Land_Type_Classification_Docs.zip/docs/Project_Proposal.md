# Project Proposal

## Objective
Develop a Deep Neural Network model to classify land types using Sentinel-2 satellite images.

## Scope
- Data collection from Sentinel-2 sources.
- Preprocessing using tools like QGIS.
- Model development and training.
- Performance evaluation.

## Expected Outcome
A functional DNN-based land classification model.
